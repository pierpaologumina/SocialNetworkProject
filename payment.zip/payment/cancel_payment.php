<?php

echo "<script>alert('IMPOSSIBILE PROCEDERE CON IL PAGAMENTO, RIPROVA!')</script>";
echo "<script>window.open('../libri.php', '_self')</script>";
