<?php
require_once('stripe-php-master/init.php');
\Stripe\Stripe::setApiKey('sk_test_QcvidYM3kWMroQ5O6Gl3aMVB005z2q4bJe');

$con = new mysqli("localhost", "pier","","social_network");
$libro=$_GET['id_libro'];
$get_libri = "SELECT * FROM libri WHERE id_libro='$libro'";
$run_libri = mysqli_query($con, $get_libri);
$row_libri = mysqli_fetch_array($run_libri);

$id_libro = $row_libri['id_libro'];
$titolo_testo = $row_libri['titolo_testo'];
$corso = $row_libri['corso'];
$edizione = $row_libri['edizione'];
$autore = $row_libri['autore'];
$caricato_da = $row_libri['caricato_da'];
$condizione = $row_libri['condizione'];
$prezzo = $row_libri['prezzo'];
$caricato_il = $row_libri['caricato_il'];
$img_libro = $row_libri['img_libro'];
$info = $row_libri['info'];

$session = \Stripe\Checkout\Session::create([
    'payment_method_types' => ['card'],
    'line_items' => [[
        'name' => 'Nome: '.$titolo_testo.'. Autore: '.$autore.'. Edizione: '.$edizione,
        'description' => 'Corso di: '.$corso,
        'amount' => ($prezzo)*100,
        'currency' => 'eur',
        'quantity' => 1
    ]],
    'success_url' => 'http://localhost:8888/socialnetwork/payment/success_payment.php?id_libro='.$libro,
    'cancel_url' => 'http://localhost:8888/socialnetwork/payment/cancel_payment.php',
]);



?>

<!DOCTYPE>
<html>
<head>
    <title>PayPage</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://js.stripe.com/v3/"></script>
    <script type="text/javascript">


        var stripe = Stripe('pk_test_l8ffWSRVbVR55wOcqMArxZ8n008VHJkdPe');
        console.log(stripe);

        stripe.redirectToCheckout({
            // Make the id field from the Checkout Session creation API response
            // available to this file, so you can provide it as parameter here
            // instead of the {{CHECKOUT_SESSION_ID}} placeholder.
            sessionId:'<?php echo $session->id ?>'
        }).then(function (result) {
            // If `redirectToCheckout` fails due to a browser or network
            // error, display the localized error message to your customer
            // using `result.error.message`.
        });

    </script>
</head>
<body>

TI STO REINDIRIZZANDO ALLA PAGINA DI ACQUISTO. ATTENDERE..


</body>
</html>